#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdbool.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <libgen.h>
#include <limits.h>
#include <fcntl.h>

#define MAX 256
#define PORT 1234
#define EOF_STR "***** EOF *****"
int n, cfd;
bool isServer = false;
char *cmd[] = {"ls","cd","pwd","mkdir","rmdir","rm","cat",NULL};
int _ls(char*), _cd(char*), _pwd(char*), _mkdir(char*), _rmdir(char*), _rm(char*), _cat(char*);
int (*fcmds[])(char *)={(int (*)())_ls,_cd,_pwd,_mkdir,_rmdir,_rm,_cat};
int getLineInfo(char*,char*,char*), ls_file(char*), ls_dir(char*);
void mode_to_letters(mode_t, char*);

int getLineInfo(char *line, char *command, char *pathname){
	char *path, tempLine[MAX]; strcpy(tempLine, line); 
	if((path = strchr(tempLine, ' ')) != NULL){
		path++;
		strcpy(pathname, path);
		strcpy(command,strtok(tempLine, " "));
	}
	else{ 
		strcpy(pathname, "");
		strcpy(command, line);
	}
	for(int i = 0; cmd[i] != NULL ; i++){
		if(!strcmp(cmd[i], command)){ 
			printf("Command: %s [Index = %d] || Path: %s\n", 
				command, i, (pathname == NULL)? "NULL": pathname);
			return i; 
		}
	}
	return -1;
}

void mode_to_letters(mode_t mode, char *str)
{
	if (S_ISDIR(mode)) { str[0] = 'd'; }
	else if (S_ISLNK(mode)) { str[0] = 'l'; }
	else { str[0] = '-'; }
    str[1] = (mode & S_IRUSR) ? 'r' : '-';
    str[2] = (mode & S_IWUSR) ? 'w' : '-';
    str[3] = (mode & S_IXUSR) ? 'x' : '-';
    str[4] = (mode & S_IRGRP) ? 'r' : '-';
    str[5] = (mode & S_IWGRP) ? 'w' : '-';
    str[6] = (mode & S_IXGRP) ? 'x' : '-';
    str[7] = (mode & S_IROTH) ? 'r' : '-';
    str[8] = (mode & S_IWOTH) ? 'w' : '-';
    str[9] = (mode & S_IXOTH) ? 'x' : '-';
    str[10] = '\0';
}

int ls_file(char *fname)
{
	struct stat fstat, *sp;
	char ftime[64], *file_ls = (char*) malloc(sizeof(char*)*250);
	strcpy(file_ls, "");
	sp = &fstat;
	if (lstat(fname, sp) < 0){
		printf("Notice: Unable to stat '%s'\n", fname);
		return (int)NULL;
	}
	char mode[11] = "";
	memset(mode,0,sizeof(mode));
	mode_to_letters(sp->st_mode, mode);
	strcat(file_ls, mode);
	char *file_info = (char*) calloc(50, sizeof(char*));
	memset(file_info,0,sizeof(file_info));
	sprintf(file_info, "%3d %3d %3d %8ld ", sp->st_nlink, sp->st_gid, sp->st_uid, sp->st_size);
	strcat(file_ls, file_info);
	free(file_info);
	strcpy(ftime, ctime(&sp->st_ctime)); //file time created in calendar form
	ftime[strlen(ftime)-1] = 0; // kill \n at end
	strcat(file_ls, ftime); strcat(file_ls, " "); //file time created
	strcat(file_ls, basename(fname)); //file basename 
	//add '/' if directory to indicate it in its name
	if(S_ISDIR(sp->st_mode)){ strcat(file_ls,"/"); }
	// get linkname if is a symbolic file
	if (S_ISLNK(sp->st_mode)){
		char linkname[50];
		// ssize_t readlink(const char *path, char *buf, size_t bufsiz): reads linkname
		readlink(fname, linkname, sizeof(linkname));
		strcat(file_ls, " -> ");
		strcat(file_ls, linkname); //linked name
	}
	strcat(file_ls, "\n");
	return (int)file_ls;
}

int ls_dir(char *dname)
{
	if(dname == NULL || !strlen(dname)){
		return (int)NULL;
	}
	char files_ls[5000];
	memset(files_ls,0,sizeof(files_ls)); 	
	int len;
    struct dirent *pDirent;
    DIR *pDir;
    pDir = opendir(dname);
    if (pDir == NULL) {
        printf ("Error: Failure to Open Directory '%s'\n", dname);
        return 1;
    }
    for(int i = 0; (pDirent = readdir(pDir)) != NULL; i++) {
    	if(isServer){
    		printf("ls_file %s%s\n", dname, pDirent->d_name);
    	}
        char *file = (char*) ls_file(pDirent->d_name);
        if(file != NULL){
			strcat(files_ls, file);
		}
		free(file);
    }
    closedir(pDir);
    char *allFiles = (char*)malloc(sizeof(char*)*(strlen(files_ls)+1));
    strcpy(allFiles, files_ls);
	memset(files_ls,0,sizeof(files_ls)); 	
    return (int)allFiles;
}

//mkdir: 
int _mkdir(char* pathname){
	return mkdir(pathname, 0755);
}

//rmdir:
int _rmdir(char* pathname){
	return rmdir(pathname);
}

//rm:
int _rm(char* pathname){
	return unlink(pathname);
}

//cd:
int _cd(char* pathname){
	return chdir(pathname);
}

//pwd: 
int _pwd(char* pathname){
	char buf[MAX];
	char *cwd = getcwd(buf, MAX);
	printf("pwd: '%s'\n", cwd);
	return (cwd != NULL)? (int)cwd : -1;
}

//cat:
int _cat(char* pathname){
	char buff[MAX];
	int n, fd;
	fd = open(pathname, O_RDONLY);
	if (fd == -1)
	{
	  printf("\tError: %s File Not Found\n", pathname);
	  return (-1);
	}
	while ((n = read(fd, buff, MAX)) > 0){
		write(1, &buff, n);
	}
	close(fd);
	return 0;
}

//ls: 
int _ls(char* pathname){
	struct stat mystat, *sp = &mystat;
	char path[1024], cwd[256];
	if(pathname == NULL || !strlen(pathname)){
		strcpy(path,  "./"); 
	}
	else{
		strcpy(path, pathname);
	}
	printf("Pathname: '%s'\n", path);
	if (lstat(path, sp) < 0){
		printf("Error: No Such Path '%s'\n", path);
		exit(1);
	}
	if (path[0] != '/'){ 
		getcwd(cwd, 256);
		strcat(cwd, "/"); strcat(cwd, path);
	}
	int r;
	if (S_ISDIR(sp->st_mode)){ r = ls_dir(path); }
	else { r = ls_file(path); } 
	if(!isServer){	
		char *str = (char*)r;
		puts(str);
		free(str);
		r = 0;
	}
	return r;
}