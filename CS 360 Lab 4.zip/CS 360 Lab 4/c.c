#include "linuxCMD.c"
#define PORT 1234

//***** Global Variables *****
struct hostent *hp;              
struct sockaddr_in  saddr; 
int sfd, r;
int SERVER_IP, SERVER_PORT;


int main(int argc, char *argv[ ])
{
	int bytes, n;
	char line[MAX], ans[MAX];
	
	printf("1. create a socket\n");
    sfd = socket(AF_INET, SOCK_STREAM, 0); 
    if (sfd < 0) { 
        printf("socket creation failed\n"); 
        exit(0); 
    }
    
    printf("2. fill in server IP and port number\n");
    bzero(&saddr, sizeof(saddr)); 
    saddr.sin_family = AF_INET; 
    saddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
    saddr.sin_port = htons(PORT); 
  
    printf("3. connect to server\n");
    if (connect(sfd, (struct sockaddr *)&saddr, sizeof(saddr)) != 0) { 
        printf("connection with the server failed...\n"); 
        exit(0); 
    }
	// sock <---> server
	puts("================ Processing Loop ================");
	while (1){
		puts("********************** Menu *********************");
	    puts("* get  put  ls   cd   pwd   mkdir   rmdir   rm  *");
	    puts("* lcat     lls  lcd  lpwd  lmkdir  lrmdir  lrm  *");
	    puts("*************************************************");
		//Handles User's Input and Validation
		printf("Input a command : ");
		bzero(line, MAX);                // zero out line[ ]
		fgets(line, MAX, stdin);         // get a line (end with \n) from stdin
		line[strlen(line)-1] = 0;        // kill \n at end
		if (line[0]==0){                  // exit if NULL line
			exit(0);
		}
		//local commands
		if(line[0] == 'l' && line[1] != 's'){
			isServer = false;	
			char command[10], pathname[MAX];
			char *l = &line[1];
			int cmdIndex = getLineInfo(l, command, pathname);
			if(cmdIndex == -1){
				printf("INVALID: '%s'\n", line);
			}
			else{
				printf("Pathname: '%s'\n", pathname);
				int value = fcmds[cmdIndex](pathname);
			}
		}
		else{
			isServer = true;
			int size = 0;
			n = write(sfd, line, MAX);
			printf("Client: Wrote %d Bytes || Output = '%s'\n", n, line);
			if(strstr(line, "get")){
				char buff[MAX];
				while((n = read(sfd, buff, MAX)) != 0)
				{
					size += n;
					printf("N = %d || Total = %d\n", n, size);
					if(!strcmp(buff, EOF_STR)){ break; }
					bzero(buff,MAX);
				}
				printf("Recieved %d bytes\n", size);
			}
			else if(strstr(line, "put")){
				char buff[MAX];
				while((n = read(sfd, buff, MAX)) != 0)
				{
					size += n;
					printf("N = %d || Total = %d\n", n, size);
					if(!strcmp(buff, EOF_STR)){ break; }
					bzero(buff,MAX);
				}
				printf("Sent %d bytes\n", size);	
			}
			else{
				n = read(sfd, &size, sizeof(int));
				const int s = size + 1;
				char str[s];
				n = read(sfd, str, s);
				printf("Client: Read %d Bytes || Input = '%s'\n",n, str);
			}
		}
	}
	return 0;	
}