#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

typedef unsigned int u32;

char* tab = "0123456789ABCDEF";

void prints(char* s) {
    int i = 0;
    while (s[i] != '\0') {
        putchar(s[i]);
        i++;
    }
}

int rpu(u32 x, int base)
{
    char c;
    if (x) {
        c = tab[x % base];
        rpu(x / base, base);
        putchar(c);
    }
}

int printu(u32 x)
{
    (x == 0) ? putchar('0') : rpu(x, 10);
    putchar(' ');
}

int printd(int x) 
{
    if (x == 0)
        putchar('0');
    else if (x < 0)
    {
        putchar('-');
        x *= -1;
        rpu(x, 10);
    }
    else
        rpu(x, 10);
    putchar(' ');
}

int printx(u32 x)
{
    (x == 0) ? putchar('0x') : rpu(x, 16);
    putchar(' ');
}

int printo(u32 x) 
{
    (x == 0) ? putchar('0') : rpu(x, 8);
    putchar(' ');
}

void myprint(char* fmt, ...)
{
    int i = 0;
    
    va_list arp;
    va_start(arp, fmt);
    while (fmt != '\0') {
        char type;
        if (fmt[i] == '%')
            type = fmt[i + 1];
        switch (type) {
            case 'c':
                putchar(va_arg(arp, int));
                break;
            case 's':
                prints(va_arg(arp, char*));
                break;
            case 'u':
                printu(va_arg(arp, u32));
                break;
            case 'd':
                printd(va_arg(arp, int));
                break;
            case 'x':
                printx(va_arg(arp, u32));
                break;
            case 'o':
                printo(va_arg(arp, u32));
                break;
        }
        i++;
    }
    va_end(arp);
}