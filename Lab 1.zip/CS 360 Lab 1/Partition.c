#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#include <sys/types.h>

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;

typedef struct partition {
	u8 drive;             // drive number FD=0, HD=0x80, etc.

	u8  head;             // starting head 
	u8  sector;           // starting sector
	u8  cylinder;         // starting cylinder

	u8  sys_type;         // partition type: NTFS, LINUX, etc.

	u8  end_head;         // end head 
	u8  end_sector;       // end sector
	u8  end_cylinder;     // end cylinder

	u32 start_sector;     // starting sector counting from 0 
	u32 nr_sectors;       // number of of sectors in partition
}Partition;

char buf[512];

void LoadPartitions(Partition* p, int pCount) {
	if (p->start_sector != 0) {
		u32 type = p->sys_type;
		u32 start = p->start_sector; 
		u32 end = p->nr_sectors + start - 1; 
		printPartitionDetails(p, end, pCount); 
		pCount++;
		LoadPartitions(++p, pCount);
	}
}

void printPartitionDetails(Partition* p, u32 end, int device) {
	printf("vdisk%d\t   ", device);
	printf("%10u  ", p->start_sector);
	printf("%4u ", end);
	printf("%7u  ", p->nr_sectors); 
	printf("%2x\n", p->sys_type); 
}

int readDisk(char* disk) {
	int infile = open(disk, O_RDONLY);
	if (infile == NULL) 
		printf("Failed to open\n");
	else 
		read(infile, buf, 512);
	return infile;
}