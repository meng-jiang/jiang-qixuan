//I know it's over before she says
//I know it falls at the water face
//I know it's over, an ocean awaits
//For a storm
//The sun on snow, rivers in rain
//Crystal ball can foresee a change
//And I know it's over, a parting of ways
//And it's done